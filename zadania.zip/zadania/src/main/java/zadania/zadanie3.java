package zadania;

import java.util.ArrayList;
import java.util.Iterator;

public class zadanie3 {
    public static void main(String[] args) {
        Iterator<Integer> it = new FibonacciIterator(10).iterator();
        while (it.hasNext()) {
            System.out.println(it.next());  
        }
        // Powinno wypisać: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
    }

    public static class FibonacciIterator implements Iterable<Integer>{

        public FibonacciIterator(int i) {
            //TODO Auto-generated constructor stub
        }

        @Override
        public Iterator<Integer> iterator() {
            return null;
        }
        
    }
}
