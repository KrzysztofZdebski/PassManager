package zadania;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class zadanie1 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
        EvenNumbersIterator iterator = new EvenNumbersIterator(numbers);

        while (iterator.hasNext()) {
            System.out.println(iterator.next());  // Powinno wypisać: 2, 4, 6, 8
        }
    }

    public static class EvenNumbersIterator implements Iterator<Integer> {

        public EvenNumbersIterator(List<Integer> numbers) {
            
        }

        @Override
        public boolean hasNext() {
            return false;
        }

        @Override
        public Integer next() {
            return null;
        }
    }
}
