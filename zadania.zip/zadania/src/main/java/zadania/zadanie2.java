package zadania;

import java.util.Iterator;

public class zadanie2 {
    public static void main(String[] args) {
        for (int i : new Range(5, 10)) {
            System.out.println(i);  // Powinno wypisać: 5, 6, 7, 8, 9
        }
    }

    public static class Range implements Iterable<Integer> {

        public Range(int start, int end) {

        }

        @Override
        public Iterator<Integer> iterator() {
            return new Iterator<Integer>() {

                @Override
                public boolean hasNext() {
                    return false;
                }

                @Override
                public Integer next() {
                    return null;
                }
            };
        }
    }
}
