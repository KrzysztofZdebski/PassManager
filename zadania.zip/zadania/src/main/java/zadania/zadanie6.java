package zadania;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import java.util.Iterator;

import com.google.gson.stream.JsonReader;

public class zadanie6 {
    public static void main(String[] args) {
        zadanie6 tmp = new zadanie6();
        URL jsonFilePath = tmp.getClass().getResource("data_zad6_large.json");
        Stream<String> stream = tmp.lazyJSONLoader(jsonFilePath.getPath());

        stream.forEach(System.out::println);  // Powinno wypisać: "name: exampleName age: exampleAge city: exampleCity"
    }

    public Stream<String> lazyJSONLoader(String filePath){
        try {
            JsonReader jsonReader = new JsonReader(new FileReader(filePath));
            jsonReader.beginArray();

            Iterable<String> iterable = () -> new Iterator<>() {

                @Override
                public boolean hasNext() {
                    return false;
                }

                @Override
                public String next() {
                    return null;
                }
            };
            return StreamSupport.stream(iterable.spliterator(), true)
                                .onClose(() -> {
                                    try {
                                        jsonReader.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                });

        } catch (Exception e) {
            e.printStackTrace();
            return Stream.empty();
        }
    }
}
