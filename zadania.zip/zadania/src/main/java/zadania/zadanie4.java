package zadania;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class zadanie4 {
    private static final Gson gson = new Gson();
    public static void main(String[] args) {
        zadanie4 tmp = new zadanie4();
        URL jsonFilePath = tmp.getClass().getResource("data_zad4.json");

        Iterator<String> it = new JsonIterator(jsonFilePath.getPath()).iterator();
        while(it.hasNext()) {
            System.out.println(it.next());  // Powinno wypisać: "name: exampleName age: exampleAge city: exampleCity"
        }
    }

    public static class JsonIterator implements Iterable<String> {
        private Reader reader;

        public JsonIterator(String jsonFilePath) {
            try {
                this.reader = new FileReader(jsonFilePath);



            } catch (FileNotFoundException e) {}
        }

        @Override
        public Iterator<String> iterator() {
            return null;
        }
    }

    public record Person(
        String name,
        String age,
        String city
    ){}
}
