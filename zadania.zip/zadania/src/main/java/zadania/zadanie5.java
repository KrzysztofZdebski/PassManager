package zadania;

import java.util.Iterator;
import java.util.stream.Stream;


public class zadanie5 {
    public static void main(String[] args) {
        FibonacciGenerator generator = new FibonacciGenerator();
        Stream.iterate(generator.iterator(), it -> it)
              .map(it -> it.next())
              .limit(10)
              .forEach(System.out::println);  // Powinno wypisać: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
    }

    public static class FibonacciGenerator implements Iterable<Integer>{

        @Override
        public Iterator<Integer> iterator() {
            return null;
        }
    }
}
